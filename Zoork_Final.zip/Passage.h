#ifndef PASSAGE_H
#define PASSAGE_H

#include <string>
#include <memory>
#include "Room.h"  // ✅ Needed to call methods like enter() on Room*

class Passage {
public:
    Passage(Room* from, Room* to, const std::string& dir, bool vis = true);
    virtual ~Passage() = default;

    virtual void enter();  // Can be overridden for special behavior

    Room* getTo() const;
    std::string getDirection() const;
    bool isVisible() const;            // ✅ Added declaration
    void setVisible(bool v);           // ✅ Optional setter

    // Locking logic
    void setLocked(bool lock);         // ✅ Added declaration
    bool isLocked() const;

    void setKeyRequired(const std::string& key);
    std::string getKeyRequired() const;

    static void createBasicPassage(Room* from, Room* to, const std::string& dir, bool visible = true);

protected:
    Room* from;
    Room* to;
    std::string direction;
    bool visible;
    bool locked;
    std::string keyRequired;
};

#endif // PASSAGE_H
