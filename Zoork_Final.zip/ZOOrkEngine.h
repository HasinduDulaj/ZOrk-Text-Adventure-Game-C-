#ifndef ZOORKENGINE_H
#define ZOORKENGINE_H

#include "Player.h"
#include "Room.h"
#include <memory>
#include <vector>
#include <string>

class ZOOrkEngine {
public:
    ZOOrkEngine(std::shared_ptr<Room> start);
    void run();

    // Command Handlers
    void handleGoCommand(std::vector<std::string> arguments);
    void handleLookCommand(std::vector<std::string> arguments);
    void handleTakeCommand(std::vector<std::string> arguments);
    void handleDropCommand(std::vector<std::string> arguments);
    void handleUseCommand(std::vector<std::string> arguments); // ✅ NEW: use command
    void handleQuitCommand(std::vector<std::string> arguments);

    // ✅ Fix: Add the inventory command declaration
    void handleInventoryCommand();

private:
    Player* player;
    bool gameOver = false;

    std::vector<std::string> tokenizeString(const std::string &input);
    std::string makeLowercase(std::string input);
    // ✅ 🔧 Add this line to fix the build error
    std::string joinWords(const std::vector<std::string>& words);
};

#endif // ZOORKENGINE_H
