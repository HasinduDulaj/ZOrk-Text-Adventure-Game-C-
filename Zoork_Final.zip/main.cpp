#include "RoomDefaultEnterCommand.h"
#include "Passage.h"
#include "Player.h"
#include "Room.h"
#include "Item.h"
#include "ZOOrkEngine.h"
#include <memory>

int main() {
    // Create all rooms according to the drawn map
    std::shared_ptr<Room> start = std::make_shared<Room>("start-room",
        "You are standing in an open field west of a white house, with a boarded front door.\nPlease type the word 'look' to see what you got in this room.\n");

    std::shared_ptr<Room> garden = std::make_shared<Room>("garden",
        "You are now in an overgrown garden with wildflowers and an old stone bench. \nPlease type the word 'look' to see what you got in this garden.\n");

    std::shared_ptr<Room> tool_shed = std::make_shared<Room>("Tool Shed",
        "You are now in a small shed filled with rusty tools and garden equipment.\nPlease type the word 'look' to see what you got in this room.\n");

    std::shared_ptr<Room> gate = std::make_shared<Room>("gate",
        "You are now in front of a wooden gate. This is the end of the House and you cannot go forward from here.\nPlease head back to the home.\n");

    std::shared_ptr<Room> front_yard = std::make_shared<Room>("front-yard",
        "You are now in a small gravel path leading to the front door of the house.\nPlease type the word 'look' to see what you got in the front yard.\n");

    std::shared_ptr<Room> living_room = std::make_shared<Room>("living-room",
        "You are now in a cozy living room with a fireplace and old paintings.\nPlease type the word 'look' to see what you got in this room.\n");

    std::shared_ptr<Room> kitchen = std::make_shared<Room>("kitchen",
        "You are now in a rustic kitchen with a wooden table and cooking utensils.\nPlease type the word 'look' to see what you got in this kitchen.\n");

    std::shared_ptr<Room> dining_room = std::make_shared<Room>("dining-room",
        "You are now in a grand dining room with a long wooden table and candle holders.\nPlease type the word 'look' to see what you got in this room.\n");

    std::shared_ptr<Room> bedroom = std::make_shared<Room>("bedroom",
        "You are now in a small bedroom with a creaky bed and a dusty mirror.\nPlease type the word 'look' to see what you got in this room.\n");

    std::shared_ptr<Room> attic = std::make_shared<Room>("attic",
        "You are now in a dusty attic filled with old boxes and forgotten items.\nPlease type the word 'look' to see what you got in the attic.\n");

    std::shared_ptr<Room> basement = std::make_shared<Room>("basement",
        "You are now in a dark, damp basement. A faint light flickers in the corner.\nPlease type the word 'look' to see what you got in the basement.\n\n");

    std::shared_ptr<Room> south_of_house = std::make_shared<Room>("south-of-house",
        "You are now facing the south side of a white house. \nYou have no items here.\n");

    // Connect rooms as per the drawn map

    // Start Room Connections
    Passage::createBasicPassage(start.get(), living_room.get(), "south", true);
    Passage::createBasicPassage(start.get(), tool_shed.get(), "west", true);
    Passage::createBasicPassage(start.get(), front_yard.get(), "east", true);
    Passage::createBasicPassage(start.get(), garden.get(), "north", true);

    // Tool Shed Connections
    Passage::createBasicPassage(tool_shed.get(), garden.get(), "northeast", true);
    Passage::createBasicPassage(tool_shed.get(), start.get(), "east", true);
    Passage::createBasicPassage(tool_shed.get(), kitchen.get(), "south", true);

    // Garden Connections
    Passage::createBasicPassage(garden.get(), gate.get(), "north", true);
    Passage::createBasicPassage(garden.get(), tool_shed.get(), "southwest", true);
    Passage::createBasicPassage(garden.get(), start.get(), "south", true);
    Passage::createBasicPassage(garden.get(), front_yard.get(), "southeast", true);

    // Gate Connection
    Passage::createBasicPassage(gate.get(), garden.get(), "south", true);

    // Front Yard Connections
    Passage::createBasicPassage(front_yard.get(), start.get(), "west", true);
    Passage::createBasicPassage(front_yard.get(), garden.get(), "northwest", true);
    Passage::createBasicPassage(front_yard.get(), south_of_house.get(), "south", true);

    // South of House Connections
    Passage::createBasicPassage(south_of_house.get(), living_room.get(), "west", true);
    Passage::createBasicPassage(south_of_house.get(), front_yard.get(), "north", true);
    Passage::createBasicPassage(south_of_house.get(), attic.get(), "south", true);

    // Living Room Connections
    Passage::createBasicPassage(living_room.get(), start.get(), "north", true);
    Passage::createBasicPassage(living_room.get(), kitchen.get(), "west", true);
    Passage::createBasicPassage(living_room.get(), south_of_house.get(), "east", true);
    Passage::createBasicPassage(living_room.get(), basement.get(), "south", true);

    // Kitchen Connections
    Passage::createBasicPassage(kitchen.get(), living_room.get(), "east", true);
    Passage::createBasicPassage(kitchen.get(), dining_room.get(), "south", true);
    Passage::createBasicPassage(kitchen.get(), tool_shed.get(), "north", true);

    // Dining Room Connections
    Passage::createBasicPassage(dining_room.get(), kitchen.get(), "north", true);

    // Bedroom Connections
    Passage::createBasicPassage(bedroom.get(), living_room.get(), "north", true);
    Passage::createBasicPassage(bedroom.get(), basement.get(), "down", true);

    // Attic Connections
    Passage::createBasicPassage(attic.get(), south_of_house.get(), "north", true);

    // Basement Connections
    Passage::createBasicPassage(basement.get(), bedroom.get(), "up", true);
    Passage::createBasicPassage(basement.get(), living_room.get(), "north", true);

    // Lock four specific passages
    garden->getPassage("north")->setLocked(true);
    garden->getPassage("north")->setKeyRequired("Gate Key");

    garden->getPassage("southwest")->setLocked(true);
    garden->getPassage("southwest")->setKeyRequired("Tool Shed Key");


    kitchen->getPassage("north")->setLocked(true);
    start->getPassage("north")->setKeyRequired("Tool Shed Key");

    basement->getPassage("up")->setLocked(true);
    basement->getPassage("up")->setKeyRequired("Bedroom Key");

    start->getPassage("west")->setLocked(true);
    start->getPassage("west")->setKeyRequired("Tool Shed Key");

    living_room->getPassage("south")->setLocked(true);
    living_room->getPassage("south")->setKeyRequired("Basement Key");

    bedroom->getPassage("up")->setLocked(true);
    bedroom->getPassage("up")->setKeyRequired("Basement Key");





    // Add essential items to rooms
    start->addItem(new Item("Torch", "A wooden torch that might be useful in dark places."));
    garden->addItem(new Item("Shovel", "A sturdy shovel for digging."));
    tool_shed->addItem(new Item("Hammer", "A well-worn hammer."));
    front_yard->addItem(new Item("Map", "A map of the house layout. Type 'look map' to view."));
    living_room->addItem(new Item("Book", "An old book with faded text."));
    kitchen->addItem(new Item("Knife", "A sharp kitchen knife."));
    dining_room->addItem(new Item("Plate", "A porcelain plate."));
    bedroom->addItem(new Item("Pillow", "A dusty pillow with floral patterns."));
    attic->addItem(new Item("Lantern", "A rusty lantern."));
    basement->addItem(new Item("Wrench", "A heavy wrench for plumbing work."));

    // 🔐 Keys added to Living Room
    living_room->addItem(new Item("Gate Key", "A small key labeled 'Gate'."));
    living_room->addItem(new Item("Tool Shed Key", "A rugged key labeled 'Tool Shed'."));
    living_room->addItem(new Item("Bedroom Key", "A key with a floral pattern engraved."));
    living_room->addItem(new Item("Basement Key", "A rusted key labeled 'Basement'."));

    // Initialize the game
    ZOOrkEngine zoork(start);
    zoork.run();

    return 0;
}
