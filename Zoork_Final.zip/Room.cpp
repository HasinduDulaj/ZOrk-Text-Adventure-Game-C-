//
// Created by Richard Skarbez on 5/7/23.
//

#include "NullPassage.h"
#include "Room.h"

#include <utility>
#include <memory>
#include <algorithm>  // For std::transform (used in case-insensitive compare)
#include <string>
#include <iostream>

static std::string makeLowercase(std::string input) {
    std::transform(input.begin(), input.end(), input.begin(), ::tolower);
    return input;
}

// Room constructors
Room::Room(const std::string &n, const std::string &d) : Location(n, d) {
    enterCommand = std::make_shared<RoomDefaultEnterCommand>(this);
}

Room::Room(const std::string &n, const std::string &d, std::shared_ptr<Command> c)
    : Location(n, d, std::move(c)) {}

// Adding a passage to the room
void Room::addPassage(const std::string &direction, std::shared_ptr<Passage> p) {
    passageMap[direction] = std::move(p);
}

// Removing a passage from the room
void Room::removePassage(const std::string &direction) {
    if (passageMap.contains(direction)) {
        passageMap.erase(direction);
    }
}

// Getting a passage in a specific direction
std::shared_ptr<Passage> Room::getPassage(const std::string &direction) {
    if (passageMap.contains(direction)) {
        return passageMap[direction];
    } else {
        std::cout << "It is impossible to go " << direction << "!\n";
        return std::make_shared<NullPassage>(this);
    }
}

// ✅ Adds an item to the room
void Room::addItem(Item* item) {
    items.push_back(item);
}

// ✅ Returns an item pointer if the name matches (case-insensitive), otherwise nullptr
Item* Room::getItem(const std::string& name) {
    std::string nameLower = makeLowercase(name);
    for (Item* item : items) {
        std::string itemName = makeLowercase(item->getName());
        if (itemName == nameLower) {
            return item;
        }
    }
    return nullptr;
}

// ✅ Removes an item from the room by name (proper implementation)
bool Room::removeItem(const std::string& name) {
    std::string nameLower = makeLowercase(name);
    for (auto it = items.begin(); it != items.end(); ++it) {
        std::string itemName = makeLowercase((*it)->getName());
        if (itemName == nameLower) {
            items.erase(it);
            return true;
        }
    }
    return false;
}

// ✅ Returns reference to item list for display in `look`
const std::vector<Item*>& Room::getItems() const {
    return items;
}
