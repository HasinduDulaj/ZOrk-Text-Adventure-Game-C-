#include "Player.h"
#include <iostream>
#include <algorithm>

// Singleton pattern for Player instance
Player *Player::playerInstance = nullptr;

void Player::setCurrentRoom(Room* room) {
    currentRoom = room;
}

Room* Player::getCurrentRoom() const {
    return currentRoom;
}

// ✅ Add item to player's inventory
void Player::addItemToInventory(Item* item) {
    inventory.push_back(item);
    std::cout << "You picked up: " << item->getName() << ".\n";
}

// ✅ Remove item from player's inventory (fixed)
bool Player::removeItemFromInventory(const std::string& itemName) {
    auto it = std::find_if(inventory.begin(), inventory.end(),
        [&](Item* item) {
            std::string itemNameLower = item->getName();
            std::transform(itemNameLower.begin(), itemNameLower.end(), itemNameLower.begin(), ::tolower);
            std::string inputNameLower = itemName;
            std::transform(inputNameLower.begin(), inputNameLower.end(), inputNameLower.begin(), ::tolower);
            return itemNameLower == inputNameLower;
        });

    if (it != inventory.end()) {
        std::cout << "You dropped: " << (*it)->getName() << ".\n";
        inventory.erase(it);
        return true;
    }
    std::cout << "You don't have a " << itemName << ".\n";
    return false;
}

// ✅ Get item from inventory (fixed)
Item* Player::getItemFromInventory(const std::string& itemName) {
    auto it = std::find_if(inventory.begin(), inventory.end(),
        [&](Item* item) {
            std::string itemNameLower = item->getName();
            std::transform(itemNameLower.begin(), itemNameLower.end(), itemNameLower.begin(), ::tolower);
            std::string inputNameLower = itemName;
            std::transform(inputNameLower.begin(), inputNameLower.end(), inputNameLower.begin(), ::tolower);
            return itemNameLower == inputNameLower;
        });

    if (it != inventory.end()) {
        return *it;
    }
    return nullptr;
}

// ✅ List items in inventory (improved)
void Player::listInventory() const {
    if (inventory.empty()) {
        std::cout << "You have no items in your inventory.\n";
        return;
    }
    std::cout << "You are carrying:\n";
    for (const auto& item : inventory) {
        std::cout << "- " << item->getName() << "\n";
    }
}
bool Player::hasItem(const std::string& itemName) {
    std::string nameLower = itemName;
    std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(), ::tolower);

    for (Item* item : inventory) {
        std::string invName = item->getName();
        std::transform(invName.begin(), invName.end(), invName.begin(), ::tolower);
        if (invName == nameLower) {
            return true;
        }
    }
    return false;
}
