#include "Passage.h"
#include "Player.h"
#include "Room.h"
#include <iostream>
#include <string>
#include <algorithm>

// Constructor
Passage::Passage(Room* from, Room* to, const std::string& dir, bool vis)
    : from(from), to(to), direction(dir), visible(vis), locked(false), keyRequired("") {}

// Accessors
Room* Passage::getTo() const {
    return to;
}

std::string Passage::getDirection() const {
    return direction;
}

bool Passage::isVisible() const {
    return visible;
}

void Passage::createBasicPassage(Room* from, Room* to, const std::string& dir, bool visible) {
    std::shared_ptr<Passage> p = std::make_shared<Passage>(from, to, dir, visible);
    from->addPassage(dir, p);
}

// ✅ Define setLocked method
void Passage::setLocked(bool isLocked) {
    locked = isLocked;
}

// ✅ Define setKeyRequired method
void Passage::setKeyRequired(const std::string& key) {
    keyRequired = key;
}

void Passage::enter() {
    Player* player = Player::instance();

    if (locked) {
        std::cout << "\nYou are in front of the " << to->getName()
                  << ". This Room's Door is locked and You Cannot Enter without a Key.\n";
        std::cout << "Do you have the key to open the door of '" << to->getName()
                  << "'? Type Yes or No: ";

        std::string response;
        std::getline(std::cin, response);
        std::transform(response.begin(), response.end(), response.begin(), ::tolower);

        if (response == "yes") {
            // Normalize expected key name
            std::string expectedKey = to->getName() + " Key";
            std::transform(expectedKey.begin(), expectedKey.end(), expectedKey.begin(), ::tolower);

            // Check inventory for matching key (case-insensitive match)
            bool keyFound = false;
            for (Item* item : player->getInventory()) {
                std::string itemName = item->getName();
                std::transform(itemName.begin(), itemName.end(), itemName.begin(), ::tolower);
                if (itemName == expectedKey) {
                    keyFound = true;
                    break;
                }
            }

            if (keyFound) {
                std::cout << " You used the " << expectedKey << " to unlock the door.\n";
                locked = false;
                player->setCurrentRoom(to);
                to->enter();
                return;
            } else {
                std::cout << " You don't have the required key.\n";
                return;
            }

        } else {
            std::cout << " You chose not to open the door.\n";
            return;
        }
    }

    // ✅ If already unlocked, allow entry
    player->setCurrentRoom(to);
    to->enter();
}