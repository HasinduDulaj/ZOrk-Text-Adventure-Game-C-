#include "Passage.h"
#include "PassageDefaultEnterCommand.h"

// ✅ Use dynamic_cast to ensure gameObject is safely cast
void PassageDefaultEnterCommand::execute() {
    if (auto* passage = dynamic_cast<Passage*>(gameObject)) {
        passage->getTo()->enter();
    }
}
