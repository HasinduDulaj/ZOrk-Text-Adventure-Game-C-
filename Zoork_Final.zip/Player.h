#ifndef ZOORK_PLAYER_H
#define ZOORK_PLAYER_H

#include "Character.h"
#include "Location.h"
#include "NullRoom.h"
#include "Item.h"
#include <vector>
#include <string>

class Player : public Character {
public:
    static Player *instance() {
        if (!playerInstance) {
            playerInstance = new Player();
        }
        return playerInstance;
    }

    void setCurrentRoom(Room*);
    Room* getCurrentRoom() const;

    void addItemToInventory(Item* item);
    bool removeItemFromInventory(const std::string& itemName);
    Item* getItemFromInventory(const std::string& itemName);
    void listInventory() const;

    // ✅ Added: check if player has a specific item
    bool hasItem(const std::string& itemName);

    // ✅ Newly added getter method for inventory
    std::vector<Item*> getInventory() const { return inventory; }

    Player(const Player &) = delete;
    Player &operator=(const Player &) = delete;

private:
    static Player *playerInstance;
    Room* currentRoom;
    std::vector<Item*> inventory;

    Player() : Character("You", "You are a person, alike in dignity to any other, but uniquely you."),
               currentRoom(new NullRoom()) {}
};

#endif //ZOORK_PLAYER_H
