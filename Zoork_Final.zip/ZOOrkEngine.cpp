#include "ZOOrkEngine.h"
#include "Item.h"

#include <utility>
#include <memory>
#include <algorithm>
#include <sstream>
#include <iostream>
#include "Passage.h"

ZOOrkEngine::ZOOrkEngine(std::shared_ptr<Room> start) {
    player = Player::instance();
    player->setCurrentRoom(start.get());
    player->getCurrentRoom()->enter();
}

void ZOOrkEngine::run() {
    while (!gameOver) {
        std::cout << "> ";
        std::string input;
        std::getline(std::cin, input);

        std::vector<std::string> words = tokenizeString(input);
        if (words.empty()) continue;

        std::string command = words[0];
        std::vector<std::string> arguments(words.begin() + 1, words.end());

        if (command == "go") {
            handleGoCommand(arguments);
        } else if ((command == "look") || (command == "inspect")) {
            handleLookCommand(arguments);
        } else if ((command == "take") || (command == "get")) {
            handleTakeCommand(arguments);
        } else if (command == "drop") {
            handleDropCommand(arguments);
        } else if (command == "inventory") {
            handleInventoryCommand();
        } else if (command == "use") {
            handleUseCommand(arguments);
        } else if (command == "quit") {
            handleQuitCommand(arguments);
        } else {
            std::cout << "I don't understand that command.\n";
        }
    }
}

void ZOOrkEngine::handleInventoryCommand() {
    player->listInventory();
}

void ZOOrkEngine::handleGoCommand(std::vector<std::string> arguments) {
    if (arguments.empty()) {
        std::cout << "Go where?\n";
        return;
    }

    std::string direction = joinWords(arguments);
    Room* currentRoom = player->getCurrentRoom();
    std::shared_ptr<Passage> passage = currentRoom->getPassage(direction);

    // ✅ Only proceed if the passage is not null
    if (!passage || passage->getTo() == nullptr || passage->getTo()->getName() == "null") {
        std::cout << "It is impossible to go " << direction << "!\n";
        return;
    }

    // ✅ Let passage handle locked-door logic
    passage->enter();
}


void ZOOrkEngine::handleLookCommand(std::vector<std::string> arguments) {
    Room* room = player->getCurrentRoom();

    if (arguments.empty()) {
        std::cout << room->getDescription();

        const auto& items = room->getItems();
        if (!items.empty()) {
            std::cout << "\nYou see:\n";
            for (Item* item : items) {
                std::cout << "- " << item->getName() << "\nPlease type 'look "  << item->getName() << "'"<< " to see the description of the " << item->getName() << ".\n";
                std::cout << "Please type 'take "  << item->getName() << "'" << " to add the " << item->getName() << " to your inventory.\n";
                std::cout << "Please type 'use "  << item->getName() << "'" << " to use the " << item->getName() << " after taking the item." << "\nBe Careful when using tools.\n";
            }
        }
    } else {
        std::string target = joinWords(arguments); // ✅ Support multi-word item names

        if (target == "map") {
            std::cout << "You are inside a house with the following rooms: \n"
                         "There is a Gate and a Garden in front of the house. \n\n"
                         "The House includes: \n"
                         "           --- Gate --- \n"
                         "           --- Garden --- \n"
                         "Tool Shed - Start Room - Front Yard \n"
                         "Kitchen - Living Room - South of House \n"
                         "Dinning Room - Basement - Attic \n"
                         "          ---- Bedroom ----         \n";
            return;
        }

        Item* item = room->getItem(target);
        if (item) {
            std::cout << item->getDescription() << "\n";
        } else {
            std::cout << "You don't see any " << target << " here.\n";
        }
    }
}

void ZOOrkEngine::handleTakeCommand(std::vector<std::string> arguments) {
    if (arguments.empty()) {
        std::cout << "Take what?\n";
        return;
    }

    std::string itemName = joinWords(arguments); // ✅ Fix: Use full multi-word item name
    Room* currentRoom = player->getCurrentRoom();
    Item* item = currentRoom->getItem(itemName);

    if (item) {
        player->addItemToInventory(item);
        currentRoom->removeItem(itemName);
        std::cout << "You picked up the " << item->getName() << ".\n";
        std::cout << "Please type 'drop "  << item->getName() << "'" << " if you want to remove the " << item->getName() << " from your inventory.\n";
    } else {
        std::cout << "There is no " << itemName << " here.\n";
    }
}

void ZOOrkEngine::handleDropCommand(std::vector<std::string> arguments) {
    if (arguments.empty()) {
        std::cout << "Drop what?\n";
        return;
    }

    std::string itemName = joinWords(arguments); // ✅ Fix: Use full multi-word item name
    Item* item = player->getItemFromInventory(itemName);

    if (item) {
        player->getCurrentRoom()->addItem(item);
        if (player->removeItemFromInventory(itemName)) {
            std::cout << "You dropped the " << itemName << ".\n";
        }
    } else {
        std::cout << "You don't have a " << itemName << ".\n";
    }
}

void ZOOrkEngine::handleUseCommand(std::vector<std::string> arguments) {
    if (arguments.empty()) {
        std::cout << "Use what?\n";
        return;
    }

    std::string itemName = joinWords(arguments);  // Convert args to lowercase joined name
    Item* item = player->getItemFromInventory(itemName);

    if (!item) {
        std::cout << "You don't have a " << itemName << " to use.\n";
        return;
    }

    // Add fun responses for the usable items you added in rooms
    if (itemName == "torch") {
        std::cout << "You light the torch. The surroundings become brighter! \n";
    } else if (itemName == "shovel") {
        std::cout << "You dig around with the shovel, but find nothing... yet. \n";
    } else if (itemName == "hammer") {
        std::cout << "You swing the hammer with purpose. Feels powerful! \n";
    } else if (itemName == "map") {
        std::cout << "You open the map and study the house layout carefully.\n";
    } else if (itemName == "book") {
        std::cout << "You open the dusty book and read an ancient tale... \n";
    } else if (itemName == "knife") {
        std::cout << "You sharpen the knife. It's ready to slice... maybe dinner. \n";
    } else if (itemName == "plate") {
        std::cout << "You admire the porcelain plate. Too fancy to eat off! \n";
    } else if (itemName == "pillow") {
        std::cout << "You rest your head on the pillow. It's oddly comforting. \n";
    } else if (itemName == "lantern") {
        std::cout << "You light the lantern. A warm glow fills the room. \n";
    } else if (itemName == "wrench") {
        std::cout << "You tighten a bolt nearby. Feels productive! \n";
    } else {
        std::cout << "You try to use the " << itemName << ", but nothing interesting happens.\n";
    }
}

void ZOOrkEngine::handleQuitCommand(std::vector<std::string> arguments) {
    std::string input;
    std::cout << "Are you sure you want to QUIT?\n> ";
    std::cin >> input;
    std::string quitStr = makeLowercase(input);

    if (quitStr == "y" || quitStr == "yes") {
        gameOver = true;
    }
}

std::vector<std::string> ZOOrkEngine::tokenizeString(const std::string &input) {
    std::vector<std::string> tokens;
    std::stringstream ss(input);
    std::string token;
    while (std::getline(ss, token, ' ')) {
        tokens.push_back(makeLowercase(token));
    }
    return tokens;
}

std::string ZOOrkEngine::makeLowercase(std::string input) {
    std::string output = std::move(input);
    std::transform(output.begin(), output.end(), output.begin(), ::tolower);
    return output;
}

// ✅ Combine all words after a command into a single lowercase string
std::string ZOOrkEngine::joinWords(const std::vector<std::string>& words) {
    std::string result;
    for (size_t i = 0; i < words.size(); ++i) {
        result += words[i];
        if (i != words.size() - 1) result += " ";
    }
    return makeLowercase(result);
}
