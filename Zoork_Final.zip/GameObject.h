//
// Created by Richard Skarbez on 5/7/23.
//

#ifndef ZOORK_GAMEOBJECT_H
#define ZOORK_GAMEOBJECT_H

#include <string>

class GameObject {
public:
    GameObject(const std::string& name, const std::string& description);

    virtual ~GameObject(); // ✅ polymorphic class

    std::string getName() const;
    void setName(const std::string& n);

    std::string getDescription() const;
    void setDescription(const std::string& d);

protected:
    std::string name;
    std::string description;
};

#endif //ZOORK_GAMEOBJECT_H
