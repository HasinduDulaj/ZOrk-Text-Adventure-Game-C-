#include "GameObject.h"

GameObject::GameObject(const std::string &n, const std::string &d)
    : name(n), description(d) {}

GameObject::~GameObject() = default;

std::string GameObject::getName() const {
    return name;
}

void GameObject::setName(const std::string &n) {
    name = n;
}

std::string GameObject::getDescription() const {
    return description;
}

void GameObject::setDescription(const std::string &d) {
    description = d;
}
