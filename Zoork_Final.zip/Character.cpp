//
// Created by Richard Skarbez on 5/7/23.
//

#include "Character.h"

Character::Character(const std::string &n, const std::string &d) : GameObject(n, d) {}
