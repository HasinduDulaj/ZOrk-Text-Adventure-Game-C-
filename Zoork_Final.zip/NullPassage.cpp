#include "NullPassage.h"

// ✅ Fix: Use correct Passage constructor
NullPassage::NullPassage(Room* from)
    : Passage(from, from, "null", false) {}
